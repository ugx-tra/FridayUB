# Taken from megadlbot_oss <https://github.com/eyaadh/megadlbot_oss/blob/master/mega/telegram/utils/custom_download.py>
# Thanks to Eyaadh <https://github.com/eyaadh>

import io
import re
import math
import secrets
import mimetypes

from aiohttp import web
from typing import Union

from pyrogram import Client, raw, utils
from pyrogram.errors import AuthBytesInvalid
from pyrogram.file_id import FileId, FileType, ThumbnailSource
from pyrogram.session import Auth, Session
from pyrogram.types import Message


from . import *



# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

routes = web.RouteTableDef()

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

async def chunk_size(length):
    return 2 ** max(min(math.ceil(math.log2(length / 1024)), 10), 2) * 1024


async def offset_fix(offset, chunksize):
    offset -= offset % chunksize
    return offset

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


class TGCustomYield:
    def __init__(self):
        """A custom method to stream files from telegram.
        functions:
            generate_file_properties: returns the properties for a media on a specific message contained in FileId class.
            generate_media_session: returns the media session for the DC that contains the media file on the message.
            yield_file: yield a file from telegram servers for streaming.
        """
        self.main_bot = app

    @staticmethod
    async def generate_file_properties(msg: Message):
        error_message = "This message doesn't contain any downloadable media"
        available_media = ("audio", "document", "photo", "sticker", "animation", "video", "voice", "video_note")

        if isinstance(msg, Message):
            for kind in available_media:
                media = getattr(msg, kind, None)

                if media is not None:
                    break
            else:
                raise ValueError(error_message)
        else:
            media = msg

        if isinstance(media, str):
            file_id_str = media
        else:
            file_id_str = media.file_id

        file_id_obj = FileId.decode(file_id_str)

        # The below lines are added to avoid a break in routes.py
        setattr(file_id_obj, "file_size", getattr(media, "file_size", 0))
        setattr(file_id_obj, "mime_type", getattr(media, "mime_type", ""))
        setattr(file_id_obj, "file_name", getattr(media, "file_name", ""))

        return file_id_obj

    async def generate_media_session(self, client: Client, msg: Message):
        data = await self.generate_file_properties(msg)

        media_session = client.media_sessions.get(data.dc_id, None)

        if media_session is None:
            if data.dc_id != await client.storage.dc_id():
                media_session = Session(
                    client, data.dc_id, await Auth(client, data.dc_id, await client.storage.test_mode()).create(),
                    await client.storage.test_mode(), is_media=True
                )
                await media_session.start()

                for _ in range(3):
                    exported_auth = await client.send(
                        raw.functions.auth.ExportAuthorization(
                            dc_id=data.dc_id
                        )
                    )

                    try:
                        await media_session.send(
                            raw.functions.auth.ImportAuthorization(
                                id=exported_auth.id,
                                bytes=exported_auth.bytes
                            )
                        )
                    except AuthBytesInvalid:
                        continue
                    else:
                        break
                else:
                    await media_session.stop()
                    raise AuthBytesInvalid
            else:
                media_session = Session(
                    client, data.dc_id, await client.storage.auth_key(),
                    await client.storage.test_mode(), is_media=True
                )
                await media_session.start()
            client.media_sessions[data.dc_id] = media_session

        return media_session


    @staticmethod
    async def get_location(file_id: FileId):
        file_type = file_id.file_type
        if file_type == FileType.CHAT_PHOTO:
            if file_id.chat_id > 0:
                peer = raw.types.InputPeerUser(
                    user_id=file_id.chat_id,
                    access_hash=file_id.chat_access_hash
                )
            else:
                if file_id.chat_access_hash == 0:
                    peer = raw.types.InputPeerChat(
                        chat_id=-file_id.chat_id
                    )
                else:
                    peer = raw.types.InputPeerChannel(
                        channel_id=utils.get_channel_id(file_id.chat_id),
                        access_hash=file_id.chat_access_hash
                    )


            location = raw.types.InputPeerPhotoFileLocation(
                peer=peer,
                volume_id=file_id.volume_id,
                local_id=file_id.local_id,
                big=file_id.thumbnail_source == ThumbnailSource.CHAT_PHOTO_BIG
            )
        elif file_type == FileType.PHOTO:
            location = raw.types.InputPhotoFileLocation(
                id=file_id.media_id,
                access_hash=file_id.access_hash,
                file_reference=file_id.file_reference,
                thumb_size=file_id.thumbnail_size
            )
        else:
            location = raw.types.InputDocumentFileLocation(
                id=file_id.media_id,
                access_hash=file_id.access_hash,
                file_reference=file_id.file_reference,
                thumb_size=file_id.thumbnail_size
            )

        return location

    async def yield_file(self, media_msg: Message, offset: int, first_part_cut: int,
                         last_part_cut: int, part_count: int, chunk_size: int) -> Union[str, None]: #pylint: disable=unsubscriptable-object
        client = self.main_bot
        data = await self.generate_file_properties(media_msg)
        media_session = await self.generate_media_session(client, media_msg)

        current_part = 1
        location = await self.get_location(data)

        r = await media_session.send(
            raw.functions.upload.GetFile(
                location=location,
                offset=offset,
                limit=chunk_size
            ),
        )

        if isinstance(r, raw.types.upload.File):
            while current_part <= part_count:
                chunk = r.bytes
                if not chunk:
                    break
                offset += chunk_size
                if part_count == 1:
                    yield chunk[first_part_cut:last_part_cut]
                    break
                if current_part == 1:
                    yield chunk[first_part_cut:]
                if 1 < current_part <= part_count:
                    yield chunk

                r = await media_session.send(
                    raw.functions.upload.GetFile(
                        location=location,
                        offset=offset,
                        limit=chunk_size
                    ),
                )

                current_part += 1

    async def download_as_bytesio(self, media_msg: Message):
        client = self.main_bot
        data = await self.generate_file_properties(media_msg)
        media_session = await self.generate_media_session(client, media_msg)


        location = await self.get_location(data)


        limit = 1024 * 1024
        offset = 0

        r = await media_session.send(
            raw.functions.upload.GetFile(
                location=location,
                offset=offset,
                limit=limit
            )
        )

        if isinstance(r, raw.types.upload.File):
            m_file = []
            # m_file.name = file_name
            while True:
                chunk = r.bytes
                if not chunk:
                    break

                m_file.append(chunk)
                offset += limit
                r = await media_session.send(
                    raw.functions.upload.GetFile(
                        location=location,
                        offset=offset,
                        limit=limit
                    )
                )
            return m_file



# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

@routes.get("/", allow_head=True)
async def root_route_handler(request):
    return web.json_response(
        {
            "server_status": "online",
            "version": "beta",
        }
    )

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


@routes.get(r"/{password}/{chat_id}/{message_id:\S+}")
async def stream_handler(request):
    try:
        pam = request.match_info["password"]
        pam = str(re.search(r"(\S+)", pam).group(1))
        if pam != DB.get("STREAMER"):
            return web.Response(text="Error 503 occured!")

        message_id = request.match_info["message_id"]
        message_id = int(re.search(r"(\d+)(?:\/\S+)?", message_id).group(1))
        chat_id = request.match_info["chat_id"]
        chat_id = str(re.search(r"(\S+)", chat_id).group(1))
        LOG.warning(f"{chat_id} ••• {message_id}")
        await media_streamer(request, chat_id, message_id)
    except ValueError as e:
        LOG.error(str(e))
        return web.Response(text="U goofed up! **regex mismatch")
    except AttributeError as e:
        LOG.error(str(e))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# For Telethon

"""
async def asst_streamer(request, chat_id, message_id):
    RANGE_REGEX = re.compile(r"bytes=([0-9]+)-")
    BLOCK_SIZE = MAX_CHUNK_SIZE
    EXT_ATTACH = [".mp4"]
    try:
        chat_id = int(chat_id)
    except:
        pass

    try:
        message = await asst.get_messages(chat_id, ids=message_id)
    except ValueError:
        return web.Response(text=f"Chat not found, try once again tho 👀 ••• Chat –> {chat_id} ••• Message ID –> {message_id}")
    
    if not (message and message.file):
        return web.Response(text=f"No Media found on this Message ID] ••• Chat –> {chat_id} ••• Message ID –> {message_id}")
    offset = request.headers.get("Range", 0)
    
    if not isinstance(offset, int):
        matches = RANGE_REGEX.search(offset)
        if matches is None:
            return web.HTTPBadRequest()
        offset = matches.group(1)
        if not offset.isdigit():
            return web.HTTPBadRequest()
        offset = int(offset)

    file_size = message.file.size
    file_ext = message.file.ext or ""
    if message.file.name:
        name = message.file.name
    else:
        name = f"{message_id}{file_ext}"

    download_skip = (offset // BLOCK_SIZE) * BLOCK_SIZE
    read_skip = offset - download_skip

    if download_skip >= file_size:
        return web.HTTPRequestRangeNotSatisfiable()

    if read_skip > BLOCK_SIZE:
        return web.HTTPInternalServerError()

    resp = web.StreamResponse(
        headers={
            "Content-Type": message.file.mime_type,
            "Accept-Ranges": "bytes",
            "Content-Range": f"bytes {offset}-{file_size}/{file_size}",
            "Content-Length": str(file_size),
            "Content-Disposition": f"attachment; filename={name}" if file_ext in EXT_ATTACH else f"inline; filename={name}",
        },
        status = 206 if offset else 200,
    )
    await resp.prepare(request)

    cls = asst.iter_download(message.media, offset=download_skip)
    async for part in cls:
        if len(part) < read_skip:
            read_skip -= len(part)
        elif read_skip:
            await resp.write(part[read_skip:])
            read_skip = 0
        else:
            await resp.write(part)
                
    return resp
"""

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# Pyro
async def media_streamer(request, chat_id: str, message_id: int):
    range_header = request.headers.get("Range", 0)
    try: chat_id = int(chat_id)
    except: pass
    try:
        await app.get_chat(chat_id)
    except:
        LOG.warning(f"Chat not found: {chat_id}")
        return web.Response(text=f"Chat not found! ••• Chat –> {chat_id} ••• Message ID –> {message_id}")

    media_msg = await app.get_messages(chat_id, message_id)
    file_properties = await TGCustomYield().generate_file_properties(media_msg)
    file_size = file_properties.file_size

    if range_header:
        from_bytes, until_bytes = range_header.replace("bytes=", "").split("-")
        from_bytes = int(from_bytes)
        until_bytes = int(until_bytes) if until_bytes else file_size - 1
    else:
        from_bytes = request.http_range.start or 0
        until_bytes = request.http_range.stop or file_size - 1

    req_length = until_bytes - from_bytes

    new_chunk_size = await chunk_size(req_length)
    offset = await offset_fix(from_bytes, new_chunk_size)
    first_part_cut = from_bytes - offset
    last_part_cut = (until_bytes % new_chunk_size) + 1
    part_count = math.ceil(req_length / new_chunk_size)
    body = TGCustomYield().yield_file(
        media_msg, offset, first_part_cut, last_part_cut, part_count, new_chunk_size
    )

    file_name = (
        file_properties.file_name
        if file_properties.file_name
        else f"{secrets.token_hex(2)}.jpeg"
    )
    mime_type = (
        file_properties.mime_type
        if file_properties.mime_type
        else f"{mimetypes.guess_type(file_name)}"
    )

    return_resp = web.Response(
        status=206 if range_header else 200,
        body=body,
        headers={
            "Content-Type": mime_type,
            "Content-Range": f"bytes {from_bytes}-{until_bytes}/{file_size}",
            "Content-Disposition": f'attachment; filename="{file_name}"',
            "Accept-Ranges": "bytes",
        },
    )

    if return_resp.status == 200:
        return_resp.headers.add("Content-Length", str(file_size))

    return return_resp

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~