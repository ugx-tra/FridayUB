
import asyncio
from aiohttp import web 

from . import *


async def web_services():
    LOGS.warning("Starting Web Services!")
    appx = web.AppRunner(await web_server())
    await appx.setup()
    bind_address = "0.0.0.0"
    await web.TCPSite(appx, bind_address, 8080).start()
    LOGS.warning(">> Web Service Started!")


async def web_server():
    from pyro.server import routes
    web_app = web.Application(client_max_size=30000000)
    web_app.add_routes(routes)
    return web_app


loop = asyncio.get_event_loop()
loop.run_until_complete(web_services())
