
import asyncio

from aiohttp import web
from decouple import config
from pyrogram import Client, __version__
from pyrogram.raw.all import layer

from . import *


async def web_services():
    LOGS.warning("Starting Web Services!")
    appx = web.AppRunner(await web_server())
    await appx.setup()
    bind_address = "0.0.0.0"
    await web.TCPSite(appx, bind_address, 8080).start()
    LOGS.warning(">> Web Service Started!")


async def web_server():
    from pyro.server import routes
    web_app = web.Application(client_max_size=30000000)
    web_app.add_routes(routes)
    return web_app


app = Client(
    session_name='Pyrogram',
    api_id=config("API_ID"),
    api_hash=config("API_HASH"),
    bot_token=config("BOT_TOKEN"),
    plugins={"root": "pyro/plugins"},
    sleep_threshold=60,
    workers=10,
)
try:
    app.start()
    me_ = app.get_me()
    LOGS.warning(f"\n\n\t</> PyroBot Started! ~ [{me_.first_name}] with Pyrogram: [v{__version__}] on Layer: {layer}")
except Exception as ex:
    LOGS.error("Error in Starting Pyrogram: " + str(ex))

loop = asyncio.get_event_loop()
loop.run_until_complete(web_services())
