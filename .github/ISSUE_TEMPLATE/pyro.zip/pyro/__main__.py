
import asyncio
import sys

from aiohttp import web
from pathlib import Path
from glob import glob
from importlib import util

from . import *


def loader(plugin):
    if "(" in plugin:
        return LOGS.warning("Plugin already exists.")
    with open(plugin) as a:
        path_ = Path(a.name)
        plugin_name = path_.stem.replace(".py", "")
        if plugin_name.startswith("__"):
            return LOGS.error(f"double underscore, ignoring {plugin}")
        plugins_dir = Path(f"pyro/plugins/{plugin_name}.py")
        import_path = f"pyro.plugins.{plugin_name}"
        spec = util.spec_from_file_location(import_path, plugins_dir)
        load = util.module_from_spec(spec)
        spec.loader.exec_module(load)
        sys.modules["pyro.plugins." + plugin_name] = load
        return LOGS.info(f"Imported {plugin_name}")


async def services():
    LOGS.info("Loading Plugins")
    for plugin in glob("pyro/plugins/*py"):
        try:
            loader(plugin)
        except Exception as ex:
            LOG.warning(str(ex))
            continue

    time.sleep(3)
    LOGS.warning("Starting Web Services!")
    appx = web.AppRunner(await web_server())
    await appx.setup()
    bind_address = "0.0.0.0"
    await web.TCPSite(appx, bind_address, 8080).start()
    LOGS.warning(">> Web Service Started!")


async def web_server():
    from pyro.server import routes
    web_app = web.Application(client_max_size=30000000)
    web_app.add_routes(routes)
    return web_app


loop = asyncio.get_event_loop()
loop.run_until_complete(services())
