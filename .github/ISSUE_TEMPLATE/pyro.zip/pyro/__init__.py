 
import os
import time
import logging

from redis import Redis
from pyrogram import Client, __version__
from pyrogram.raw.all import layer



os.environ["TZ"] = "Asia/Kolkata"
time.tzset()
WebStartTime = time.time()

logging.basicConfig(format='%(asctime)s – %(name)s - %(levelname)s — %(message)s',
    handlers=[logging.FileHandler('pyro.log'), logging.StreamHandler()],
    level=logging.WARNING)

LOG = logging.getLogger(__name__)


app = Client(
    session_name='Pyrogram',
    api_id=config("API_ID"),
    api_hash=config("API_HASH"),
    bot_token=config("BOT_TOKEN"),
    plugins={"root": "pyro/plugins"},
    sleep_threshold=60,
    workers=10,
)
try:
    app.start()
    me_ = app.get_me()
    LOG.warning(f"\n\n\t</> PyroBot Started! ~ [{me_.first_name}] with Pyrogram: [v{__version__}] on Layer: {layer}")
except Exception as ex:
    LOG.error("Error in Starting Pyrogram:" + str(ex))


def xdb(uri, password):
    ho, po = uri.split(":")
    cp = Redis(
        host=ho,
        port=po,
        password=password,
        decode_responses=True,
        retry_on_timeout=True,
        socket_timeout=5
    )
    try:
        if cp.ping():
            LOG.warning("Redis Connected")
            return cp
        return
    except:
        return


# logging.getLogger("pyrogram").setLevel(logging.WARNING)

DB = xdb(
    config("REDIS_URI"),
    config("REDIS_PASSWORD")
)
