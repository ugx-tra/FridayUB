 
import os
import time
import logging

from redis import Redis


os.environ["TZ"] = "Asia/Kolkata"
time.tzset()
WebStartTime = time.time()

logging.basicConfig(format='%(asctime)s – %(name)s - %(filename)s - %(levelname)s — %(message)s',
    handlers=[logging.FileHandler('pyro.log'), logging.StreamHandler()],
    level=logging.INFO)

LOGS = logging.getLogger(__name__)


def xdb(uri, password):
    ho, po = uri.split(":")
    cp = Redis(
        host=ho,
        port=po,
        password=password,
        decode_responses=True,
        retry_on_timeout=True,
        socket_timeout=5
    )
    try:
        if cp.ping():
            LOGS.warning("Redis Connected")
            return cp
        return
    except:
        return


DB = xdb(
    config("REDIS_URI"),
    config("REDIS_PASSWORD")
)
