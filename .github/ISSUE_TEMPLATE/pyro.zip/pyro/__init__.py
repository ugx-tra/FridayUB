 
import os
import time
import logging

from decouple import config
from redis import Redis
from pyrogram import Client, __version__
from pyrogram.raw.all import layer


os.environ["TZ"] = "Asia/Kolkata"
time.tzset()
WebStartTime = time.time()

logging.basicConfig(format='%(asctime)s – %(name)s - %(filename)s - %(levelname)s — %(message)s',
    handlers=[logging.FileHandler('pyro.log'), logging.StreamHandler()],
    level=logging.INFO)

LOGS = logging.getLogger(__name__)


def xdb(uri, password):
    ho, po = uri.split(":")
    cp = Redis(
        host=ho,
        port=po,
        password=password,
        decode_responses=True,
        retry_on_timeout=True,
        socket_timeout=5
    )
    try:
        if cp.ping():
            LOGS.warning("Redis Connected")
            return cp
        return
    except:
        return


DB = xdb(
    os.getenv("REDIS_URI"),
    os.getenv("REDIS_PASSWORD"),
)


app = Client(
    session_name='Pyrogram',
    api_id=os.getenv("API_ID"),
    api_hash=os.getenv("API_HASH"),
    bot_token=os.getenv("BOT_TOKEN"),
    plugins={"root": "pyro/plugins"},
    sleep_threshold=60,
    workers=20,
)
try:
    app.start()
    me_ = app.get_me()
    LOGS.warning(f"\n\n\t</> PyroBot Started! ~ [{me_.first_name}] with Pyrogram: [v{__version__}] on Layer: {layer}")
except Exception as ex:
    LOGS.error("Error in Starting Pyrogram: " + str(ex))
