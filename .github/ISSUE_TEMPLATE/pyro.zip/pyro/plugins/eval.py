

import os
import re
import io
import sys
import json
import asyncio
import requests
import traceback
import subprocess

from pyrogram import Client, filters
from pyrogram.types import Message

from io import StringIO
from pprint import pprint
from pyrogram.types import (
    InlineKeyboardButton as ikb,
    InlineKeyboardMarkup as ikm,
)

from . import *


LOGGY = int(DB.get("LOGGY"))
usersss = [int(i) for i in DB.get("FULLSUDO").split()]
p, pp = print, pprint


async def bash(cmd):
    process = await asyncio.create_subprocess_shell(
        cmd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, stderr = await process.communicate()
    err = stderr.decode().strip()
    out = stdout.decode().strip()
    return out, err


async def apexec(code, client, message):
    c = chat = message.chat.id
    m = message
    app = client
    rm = reply = message.reply_to_message
    exec(
        f"async def __aexec(client, c, app, m, rm, message): "
        + "".join(f"\n {l}" for l in code.split("\n"))
    )
    return await locals()["__aexec"](client, c, app, m, rm, message)
        

@app.on_message(filters.user(usersss) & filters.command("pe"))
async def eval_pyro(app, message):
    try:
        cmd = message.text.split(maxsplit=1)[1]
    except IndexError:
        return

    sm = await message.reply('Processing ...')
    frm = f"**Evaluated by :**  {message.from_user.mention} \n**Link :**  {message.link}"
    old_stderr = sys.stderr
    old_stdout = sys.stdout
    redirected_output = sys.stdout = StringIO()
    redirected_error = sys.stderr = StringIO()
    stdout, stderr, exc = None, None, None
    try:
        await apexec(cmd, app, message)
    except Exception:
        exc = traceback.format_exc()
    stdout = redirected_output.getvalue()
    stderr = redirected_error.getvalue()
    sys.stdout = old_stdout
    sys.stderr = old_stderr
    evaluation = ""
    if exc:
        evaluation = exc
    elif stderr:
        evaluation = stderr
    elif stdout:
        evaluation = stdout
    else:
        evaluation = "Success"

    final_output = f"**>**  `{cmd}` \n\n**>>**  `{evaluation.strip()}`"
    if len(final_output) > 4096:
        filename = "_pyro.txt"
        with open(filename, "w+", encoding="utf8") as out_file:
            out_file.write(str(final_output))
        await message.reply_document(
            document=filename,
            caption=f"**>>** `{cmd[:300]}`",
            disable_notification=True,
        )
        os.remove(filename)
        await sm.delete()
    else:
        await sm.edit(str(final_output))

    await app.send_message(
        LOGGY,
        f"**Eval Command! PyroBot:** \n\n> `{cmd}` \n > {frm}",
        disable_web_page_preview=True,
        disable_notification=True,
    )


@app.on_message(filters.user(usersss) & filters.command("sh"))
async def loggy(app, message):
    try:
        cmd = message.text.split(maxsplit=1)[1]
    except:
        return
    msg_ = await event.reply("`Processing ...`")
    out, err = await bash(cmd)
    xx = f"`> py$~`  `{cmd}`\n\n"
    if err:
        xx += f"`> err$~`  `{err}`\n\n"
    if out:
        _k = out.split("\n")
        o_ = "\n".join(_k)
        xx += f"> `{o_}`"
    if not err and not out:
        xx += "`> Success`"
    if len(xx) > 4000:
        out = xx.replace("`", "").replace("*", "").replace("_", "")
        with open("bash_.txt", "w+", encoding="utf8") as out_file:
            out_file.write(str(out))
        await msg_.reply(f"**CMD :**\n`{cmd[:200]}`\n ....", file="bash_.txt")
        await msg_.delete()
        os.remove("bash_.txt")
    else:
        await msg_.edit(xx)

